/*
 * game.c
 *
 * Contains functions relating to the play of the game Teeko
 *
 * Authors: Luke Kamols, Jarrod Bennett
 */ 

#include "game.h"
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include "display.h"
#include "terminalio.h"
#include "serialio.h"
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include "timer0.h"
#define F_CPU 8000000UL
#include <util/delay.h>

// Start pieces in the middle of the board
#define CURSOR_X_START ((int)(WIDTH/2))
#define CURSOR_Y_START ((int)(HEIGHT/2))
#define NUM_OF_DIRECTIONS 4


uint8_t board[WIDTH][HEIGHT];
// cursor coordinates should be /* SIGNED */ to allow left and down movement.
// All other positions should be unsigned as there are no negative coordinates.
int8_t cursor_x;
int8_t cursor_y;
int8_t current_x;
int8_t current_y;
uint8_t cursor_visible;
uint8_t current_player;
uint8_t piece_picked; // piece has not been picked up = 0, piece has been picked up = 1
uint8_t piece_count; //  number of pieces placed on the board
uint8_t piece_at_cursor;
volatile uint8_t in_a_row;
int8_t dx[NUM_OF_DIRECTIONS] = {0,1,1,1};
int8_t dy[NUM_OF_DIRECTIONS] = {1,1,0,-1};
uint8_t seven_seg[10] = {63,6,91,79,102,109,125,7,127,111};
uint8_t win_count;
volatile uint8_t winner;
volatile uint8_t highest_count;
volatile uint8_t current_count_player1;
volatile uint8_t current_count_player2;
volatile uint8_t game_difficulty;
volatile uint16_t count;
volatile uint8_t display; /* 0 = right, 1 = left */
uint8_t reached_zero;
uint8_t game_paused;
uint8_t phase2;
uint8_t transition;






void initialise_game(void) {
	
	// initialise the display we are using
	initialise_display();
	
	// initialise the board to be all empty
	for (uint8_t x = 0; x < WIDTH; x++) {
		for (uint8_t y = 0; y < HEIGHT; y++) {
			board[x][y] = EMPTY_SQUARE;
		}
	}
	
	// set the starting player
	current_player = PLAYER_1;
	DDRD = (1<<DDD2); // Set PORT D PIN2 to be an output for LED legal move;
	DDRA = (1<<DDA3); // Set PORT D PIN3 to be an output for SS display.
	DDRC = 0xFF; // Set PORTC to be an output

	// also set where the cursor starts
	cursor_x = CURSOR_X_START;
	cursor_y = CURSOR_Y_START;
	cursor_visible = 0;
	piece_picked = 0;
	current_x = 0;
	current_y = 0;
	win_count = 0;
	piece_count = 0;
	piece_at_cursor = 0;
	winner = 0;
	in_a_row = 0;
	highest_count = 0;
	current_count_player1 = 0;
	current_count_player2 = 0;
	display = 0;
	game_difficulty = 0;
	count = 2000;
	reached_zero = 0;
	game_paused = 0;
	phase2 = 0;
	transition = 0;
	
	
	
}


int8_t get_current_x(void){
	
	int8_t x = cursor_x;
	return x;
}

int8_t get_current_y(void){
	
	int8_t y = cursor_y;
	return y;
}

void board_off(void) {
	
	if (win_count != 1){
		for (int x = 0; x < WIDTH; x++) {
			for (int y = 0; y < HEIGHT; y++) {
				if (board[x][y] != EMPTY_SQUARE) {
					update_square_colour(x,y,EMPTY_SQUARE);
				}
			}
		}
	} else if (win_count == 1) {
		for (int x = 0; x < WIDTH; x++) {
			for (int y = 0; y < HEIGHT; y++) {
				if (board[x][y] == current_player) {
					update_square_colour(x,y,EMPTY_SQUARE);
				}
			}
		}
	}
}

void board_on(void) {
	
	if (win_count != 1){
		for (int x = 0; x < WIDTH; x++) {
			for (int y = 0; y < HEIGHT; y++) {
				if (board[x][y] != EMPTY_SQUARE) {
					uint8_t piece = get_piece_at(x,y);
					update_square_colour(x,y,piece);
				}
			}
		}
	} else if (win_count == 1) {
		for (int x = 0; x < WIDTH; x++) {
			for (int y = 0; y < HEIGHT; y++) {
				if (board[x][y] == current_player) {
					update_square_colour(x,y,current_player);
				}
			}
		}
		
	}
}

uint8_t get_piece_at(uint8_t x, uint8_t y) {
	// check the bounds, anything outside the bounds
	// will be considered empty
	if (x < 0 || x >= WIDTH || y < 0 || y >= WIDTH) {
		return EMPTY_SQUARE;
	} else {
		//if in the bounds, just index into the array
		return board[x][y];
	}
}

void game_transition(void) {
	
	
	if (piece_count == 8 || win_count == 1) {
		transition = 1;
		uint32_t flash_time, current_time;
		uint8_t flashes;
		uint8_t pieces_visible;
		pieces_visible = 1;
		flashes = 0;
		flash_time = get_current_time();
		current_time = get_current_time();
		move_terminal_cursor(10,17);
		printf_P(PSTR("Flash: %d"), flash_time);
		
		while (flashes < 5) {
			current_time = get_current_time();
			if (current_time >= flash_time + 300 && pieces_visible) {
				board_off();
				pieces_visible = 0;
				flash_time = current_time;
			}
			current_time = get_current_time();
			if (current_time >= flash_time + 300 && !pieces_visible) {
				board_on();
				pieces_visible = 1;
				flash_time = current_time;
				flashes++;
			}
		} 
		piece_count++;
		transition = 0;

	}
}

void update_player_row_count(void) {
	
	if (in_a_row > highest_count) {
		highest_count = in_a_row;
	}
}

void update_player_count (void) {
	
	if (current_player == PLAYER_1) {
		current_count_player1 = highest_count;
		move_terminal_cursor(10,17);
		printf_P(PSTR("Player1: %d"),current_count_player1);
	}
	else if(current_player == PLAYER_2) {
		current_count_player2 = highest_count;
		move_terminal_cursor(10,18);
		printf_P(PSTR("Player2: %d"),current_count_player2);
	}
}
void flash_cursor(void) {
	
	if (game_paused == 0) {
		if (cursor_x >= 0 && cursor_x < WIDTH && cursor_y >= 0 && cursor_y < HEIGHT){
			if (cursor_visible) {
				// we need to flash the cursor off, it should be replaced by
				// the colour of the piece which is at that location
				//uint8_t piece_at_cursor = get_piece_at(cursor_x, cursor_y);
				piece_at_cursor = get_piece_at(cursor_x,cursor_y);
				update_square_colour(cursor_x, cursor_y, piece_at_cursor);
			}
			else {
			
				if (piece_picked && piece_count < 8) {
					update_square_colour(cursor_x, cursor_y, PICKED);
				}
				else if (piece_at_cursor == EMPTY_SQUARE && piece_picked && piece_count >= 8 
				&& (cursor_x != current_x || cursor_y != current_y) ) {
					update_square_colour(cursor_x,cursor_y, LEGAL);
				}
				else {
					update_square_colour(cursor_x, cursor_y, CURSOR);
				}
			
			}
		}
	
		cursor_visible = 1 - cursor_visible; //alternate between 0 and 1
	}
}

void reset_count(void) {
	
	if(game_difficulty == 1) {
		count = 2000;
	}
	else if (game_difficulty == 2) {
		count = 1000;
	}
}


void check_directions(int x_loc, int y_loc) {
	int check_x = x_loc;
	int check_y = y_loc;
	
	for (int i = 0; i < NUM_OF_DIRECTIONS; i++) {
		move_terminal_cursor(11,12);
		printf_P(PSTR("In a row: %d"),in_a_row);
		if (in_a_row == 4){
			check_winner();
			game_transition();
			win_count++;
		}
		
		in_a_row = 1;
		move_terminal_cursor(11,8);
		printf_P(PSTR("X: %d"), x_loc);
		move_terminal_cursor(11,10);
		printf_P(PSTR("Y: %d"), y_loc);
	
		
		check_x = x_loc;
		check_y = y_loc;
		while (check_x >=0 && check_x < WIDTH && check_y >= 0 && check_y < HEIGHT){
			check_x += dx[i];
			check_y += dy[i];
			if (check_x < 0 || check_x > WIDTH - 1 || check_y < 0 || check_y > HEIGHT - 1) {
				check_x = x_loc;
				check_y = y_loc;
				break;
			}
			else if (board[check_x][check_y] == current_player) {
				in_a_row++;
			}
			else if (board[check_x][check_y] != current_player) {
				check_x = x_loc;
				check_y = y_loc;
				break;
			}
		}
		
		while (check_x >=0 && check_x < WIDTH && check_y >= 0 && check_y < HEIGHT) {
			check_x -= dx[i];
			check_y -= dy[i];
			if (check_x < 0 || check_x > WIDTH - 1 || check_y < 0 || check_y > HEIGHT - 1) {
				check_x = x_loc;
				check_y = y_loc;
				break;
			}
			else if (board[check_x][check_y] == current_player) {
				in_a_row++;
			}
			else if (board[check_x][check_y] != current_player) {
				check_x = x_loc;
				check_y = y_loc;
				break;
			}
		}
		update_player_row_count();
	}
}

void check_rows(void) {
	for (int x = 0; x < WIDTH; x++) {
		for (int y = 0; y < HEIGHT; y++) {
			if (board[x][y] == current_player) {
				// Now call function to check each direction
				check_directions(x,y);
			}
		}
	}
}

uint8_t is_game_over(void) {
	
	if (win_count) {
		
		return 1;
	}
	
	return 0;
}
void is_legal(void) {
	// Check if current cursor position in game phase 1 or 2 is a legal move.
	//For game phase 1.
	
	if (piece_count < 8) {
		if (piece_at_cursor == EMPTY_SQUARE) {
			PORTD = (1<<PIND2);
		}
		if (piece_at_cursor != EMPTY_SQUARE){
			PORTD = (0<<PIND2);
		}
	} else {
		
		if (!piece_picked) {
			if (piece_at_cursor == current_player) {
				PORTD = (1<<PIND2);
			}
			else {
				PORTD = (0<<PIND2);
			}
		}
		// For game phase 2
		else if (piece_picked) {
			if (piece_at_cursor == EMPTY_SQUARE && (cursor_x != current_x || cursor_y != current_y) ) {
				PORTD = (1<<PIND2);
			}
			if (piece_at_cursor != EMPTY_SQUARE || (cursor_x == current_x && cursor_y == current_y)){
				PORTD = (0<<PIND2);
			}
		}

}
	}

	
//check the header file game.h for a description of what this function should do
// (it may contain some hints as to how to move the cursor)
void move_display_cursor(int8_t dx, int8_t dy) {
	
	// Check square at current cursor location,
	// Update with current piece,
	// Update cursor location and set visibility to 0
	
	//uint8_t piece_at_cursor = get_piece_at(cursor_x, cursor_y);
	
	
	if (game_paused == 0){
		piece_at_cursor = get_piece_at(cursor_x, cursor_y);
		update_square_colour(cursor_x, cursor_y, piece_at_cursor);
		
	
		// If piece is picked up get current x,y location and ensure 
		if (piece_picked) {
			
			cursor_x += dx;
			cursor_y += dy;
			cursor_visible = 0;
		
			if(cursor_x < 0) {
				cursor_x += 1;
			}
			else if(cursor_x >= WIDTH) {
				cursor_x -= 1;
			}
			else if(cursor_y < 0) {
				cursor_y += 1;
			}
			else if(cursor_y >= HEIGHT){
				cursor_y -= 1;
			}
		
			if (cursor_x < current_x - 1) {
				//uint8_t piece_at_cursor = get_piece_at(cursor_x, cursor_y);
				piece_at_cursor = get_piece_at(cursor_x, cursor_y);
				update_square_colour(cursor_x, cursor_y, piece_at_cursor);
				cursor_x += 1;
			}
			else if (cursor_x > current_x + 1) {
				//uint8_t piece_at_cursor = get_piece_at(cursor_x, cursor_y);
				piece_at_cursor = get_piece_at(cursor_x, cursor_y);
				update_square_colour(cursor_x, cursor_y, piece_at_cursor);
				cursor_x -= 1;
			}
			else if (cursor_y < current_y - 1) {
				//uint8_t piece_at_cursor = get_piece_at(cursor_x, cursor_y);
				piece_at_cursor = get_piece_at(cursor_x, cursor_y);
				update_square_colour(cursor_x, cursor_y, piece_at_cursor);
				cursor_y += 1;
			
			}
			else if (cursor_y > current_y + 1) {
				//uint8_t piece_at_cursor = get_piece_at(cursor_x, cursor_y);
				piece_at_cursor = get_piece_at(cursor_x, cursor_y);
				update_square_colour(cursor_x, cursor_y, piece_at_cursor);
				cursor_y -= 1;
			}
		
		
		}

		if (!piece_picked) {	
			
			cursor_x += dx;
			cursor_y += dy;
			cursor_visible = 0;
	
			if(cursor_x < 0) {
				cursor_x += WIDTH;
			}
		
			else if(cursor_x >= WIDTH) {
				cursor_x -= WIDTH;			
			}
		
			else if(cursor_y < 0) {
				cursor_y += HEIGHT;
			}
			else if(cursor_y >= HEIGHT){
				cursor_y -= HEIGHT;
			}
		}
		piece_at_cursor = get_piece_at(cursor_x, cursor_y);
		flash_cursor();
		move_terminal_cursor(10,15);
		printf_P(PSTR("X:Y %d,%d"),cursor_x, cursor_y);

	
	}
}

void piece_placement(void) {
	
	if (game_paused == 0) {
		//uint8_t piece_at_cursor = get_piece_at(cursor_x, cursor_y);
		piece_at_cursor = get_piece_at(cursor_x, cursor_y);
		// Places a piece on the board until it reaches 8 pieces.
		if (piece_count < 8) {
			// If square is empty can place a piece.
			if (piece_at_cursor == EMPTY_SQUARE){
				board[cursor_x][cursor_y] = current_player;
				check_rows();
				update_player_count();
				reset_count();
				current_player = 3 - current_player;
				piece_count++;
			}
		}
			
		if (!piece_picked && piece_at_cursor == current_player && piece_count >= 8) {
			board[cursor_x][cursor_y] = EMPTY_SQUARE;
			piece_picked = 1;
			current_x = get_current_x();
			current_y = get_current_y();
		}
		if (piece_picked && piece_at_cursor == EMPTY_SQUARE
		 && (cursor_x != current_x || cursor_y != current_y)) {
			board[cursor_x][cursor_y] = current_player;
			check_winner();
			check_rows();
			update_player_count();
			reset_count();
			piece_picked = 0;
			if (win_count != 1){
				current_player = 3 - current_player;
			}
		 }
		 highest_count = 0;
	}
	 
}

void player_update(void) {
	
	if (current_player == PLAYER_1) {
		move_terminal_cursor(10,2);
		printf_P(PSTR("                                 "));
		move_terminal_cursor(10,2);
		printf_P(PSTR("Current Player: Player1(Green)"));
	}
	if (current_player == PLAYER_2) {
		move_terminal_cursor(10,2);
		printf_P(PSTR("                                 "));
		move_terminal_cursor(10,2);
		printf_P(PSTR("Current Player: Player2(Red)"));
		
	}
}

void reset_game(void) {
	win_count = 0;
	is_game_over();
}

void check_winner(void) {
	
	if ((game_difficulty == 1 || game_difficulty == 2) && reached_zero == 1) {
		if (current_player == PLAYER_1) {
			winner = 2;
		}
		else if (current_player == PLAYER_2) {
			winner = 1;
		}
	}
	else {
		if (current_player == PLAYER_1) {
			winner = 1;
		}
		else if (current_player == PLAYER_2) {
			winner = 2;
		}
	}
}

void winner_message() {
	
	if (winner == 1) {
		printf_P(PSTR("Congratulations Player 1! You're the winner!"));
	}
	else if (winner == 2) {
		printf_P(PSTR("Congratulations Player 2! You're the winner!"));
	}
}


void display_digit(uint8_t number, uint8_t digit){
	
	if (game_difficulty == 0) {
		
		PORTC = 0;
		PORTA = (digit<<PINA3);
		PORTC = seven_seg[number]; // Numbers 0, 1, 2, 3, 4.
	}

}

void longest_line_display(void) {
	
	uint8_t value;
	value = 0;
	
	if (game_difficulty == 0){
	
		if (display == 1) {
			value = current_count_player1;
		}
		else if (display == 0) {
			value = current_count_player2;
		}
		display_digit(value, display);
		
		display = 1^ display;
		
	}
	
}

void pause_game(void) {
	game_paused = 1 - game_paused;
}


void set_game_mode(uint8_t difficulty) {

	if (difficulty == 0) {// Easy mode; No time limit
		game_difficulty = 0;
	}
	else {
		OCR1A = 9999; /* Clock divided by 8 - count for 10000 cycles */
		TCCR1A = 0; /* CTC mode */
		TCCR1B = (1<<WGM12)|(1<<CS11); /* Divide clock by 8 */
		TIMSK1 = (1<<OCIE1A); // Enable interrupt on timer output compare match.
		TIFR1 = (1<<OCF1A);
		sei();
	
		
		if (difficulty == 1) { // Medium mode; time limit of 20 secs per move.
			game_difficulty = 1;
			reset_count();
		}
		else if (difficulty == 2) {
			game_difficulty = 2;
			reset_count();
		}
}
	}


void timer(void) {
	
		if (game_difficulty != 0) {
		
			if (count == 0) {
				reached_zero++;
				win_count++;
				
			}
		
			if (display == 0) { // Right hand display
				if (count > 1000) {
					PORTC = seven_seg[(count/100)%10];
					PORTA = (display<<PINA3);
				}
				else {
					PORTC = seven_seg[(count/10)%10];
					PORTA = (display<<PINA3);
				}
			}
			else if (display == 1) { // Left hand display
				if (count > 1000) {
					PORTC = seven_seg[(count/1000)%10];
					PORTA = (display<<PINA3);
				}
				else {
					PORTC = seven_seg[(count/100)%10] | 0x80;
					PORTA = (display<<PINA3);
				}
			
			}
			if (game_paused == 0 && transition == 0){
			count--;
			}
		}
	}

ISR(TIMER1_COMPA_vect) {
	timer();
	display = 1 - display;
}







