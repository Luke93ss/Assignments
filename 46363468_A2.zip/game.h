/*
** game.h
**
** Authors: Luke Kamols
**
** Function prototypes for those functions available externally
*/


#ifndef GAME_H_
#define GAME_H_

#include <stdint.h>

// initialise the display of the board, this creates the internal board
// and also updates the display of the board
void initialise_game(void);

// returns which piece is located at position (x,y)
// the value returned will be SQUARE_EMPTY, SQUARE_P1 or SQUARE_P2
// anything outside the bounds of the boards will be SQUARE_EMPTY
uint8_t get_piece_at(uint8_t x, uint8_t y);

// update the cursor display, by changing whether it is visible or not
// call this function at regular intervals to have the cursor flash
void flash_cursor(void);

// moves the position of the cursor by (dx, dy) such that if the cursor
// started at (cursor_x, cursor_y) then after this function is called, 
// it should end at ( (cursor_x + dx) % WIDTH, (cursor_y + dy) % HEIGHT)
// the cursor should be displayed after it is moved as well
void move_display_cursor(int8_t dx, int8_t dy);

// attempt to place a piece at the current position. If successful, the
// active player is switched.
void piece_placement(void);
// prints the current player to the terminal.
void player_update(void);
// Checks if a move is legal.
void is_legal(void);
// returns 1 if the game is over, 0 otherwise
uint8_t is_game_over(void);

void reset_game(void);

void check_directions(int x_loc, int y_loc);

void tests(void);

void check_winner(void);

void winner_message(void);

void longest_line_display(void);

void set_game_mode(uint8_t difficulty);

void game_mode(void);

void timer(void);
	
void pause_game(void);

void game_transition(void);





#endif

